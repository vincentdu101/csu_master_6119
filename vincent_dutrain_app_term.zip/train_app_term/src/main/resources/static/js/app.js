$(function () {
    StompClient.init(Stations.update, Trains.update, Seats.update);


});

